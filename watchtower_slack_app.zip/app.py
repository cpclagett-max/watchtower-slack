import os
from flask import Flask, request, jsonify
import openai
from slack_sdk.web import WebClient
from slack_sdk.signature import SignatureVerifier
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

SLACK_BOT_TOKEN = os.environ["SLACK_BOT_TOKEN"]
SLACK_SIGNING_SECRET = os.environ["SLACK_SIGNING_SECRET"]
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]

client = WebClient(token=SLACK_BOT_TOKEN)
verifier = SignatureVerifier(SLACK_SIGNING_SECRET)
openai.api_key = OPENAI_API_KEY

WATCHTOWER_SYSTEM_PROMPT = """You are WatchtowerGPT, a digital operations commander... (shortened here for brevity – paste full prompt)"""

@app.route("/slack/events", methods=["POST"])
def slack_events():
    if not verifier.is_valid_request(request.get_data(), request.headers):
        return "invalid request", 403

    payload = request.form
    if "text" in payload:
        user_input = payload["text"]
        channel_id = payload["channel_id"]

        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": WATCHTOWER_SYSTEM_PROMPT},
                {"role": "user", "content": user_input}
            ],
            temperature=0.2,
        )

        reply = response["choices"][0]["message"]["content"]
        client.chat_postMessage(channel=channel_id, text=reply)

    return "", 200

if __name__ == "__main__":
    app.run(port=3000)
